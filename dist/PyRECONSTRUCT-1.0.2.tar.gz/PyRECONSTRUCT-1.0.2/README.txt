===========
PyRECONSTRUCT
===========
Date Created: 3/7/2013
Authors: Michael Musslewhite, Larry Lindsey

PyRECONSTRUCT provides easy access to XML files associated with the program RECONSTRUCT.
This package should also be used to develop scripts/programs for various tasks that use
these XML files. Included examples are mergeTool for merging multiple RECONSTRUCT series
and excelTool for pushing object data into an excel workbook (.xlsx).

---------------------------------------------------------------------------
INSTALLATION
---------------------------------------------------------------------------
PyRECONSTRUCT can be installed in multiple ways:
	
	The easiest being through pip*:
		pip install PyRECONSTRUCT
	
	Alternatively (from parent folder):
		python setup.py install
	
	*this method can have problems. Specifically, prerequisite packages may not install correctly
	on their own and will interrupt the PyRECONSTRUCT installation

These dependencies are required to run on a linux system (currently working to get functionality on Windows):
	python-dev
	python-setuptools
	libgeos-dev
	libblas-dev
	liblapack-dev
	libfreetype6-dev
	libpng-dev
	gfortran
	libxml2-dev
	libxslt-dev
	cmake
	libshiboken-dev

---------------------------------------------------------------------------
IMPORTING INTO PYTHON
---------------------------------------------------------------------------
PyRECONSTRUCT should be imported with the name 'pyrecon' (i.e. import pyrecon)

To import only the XML-parse portion of PyRECONSTRUCT:
	
	from pyrecon.tools import classes
		or
	from pyrecon.tool.classes import * 

---------------------------------------------------------------------------

----------------------------------------------------------------------------

More info on RECONSTRUCT can be found here:
	http://synapses.clm.utexas.edu/tools/index.stm

