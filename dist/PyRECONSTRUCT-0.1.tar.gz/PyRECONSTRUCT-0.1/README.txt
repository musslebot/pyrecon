===========
PyRECONSTRUCT
===========
Date Created: 3/7/2013
Authors: Michael Musslewhite, Larry Lindsey

PyRECONSTRUCT provides relatively easy access to XML files associated with the program RECONSTRUCT
using the Python programming language. This package also be used to develop scripts/programs for 
various tasks associated with these XML files.

More info on RECONSTRUCT can be found here:
	http://synapses.clm.utexas.edu/tools/index.stm

